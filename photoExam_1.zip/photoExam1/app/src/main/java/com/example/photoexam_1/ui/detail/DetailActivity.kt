package com.example.photoexam_1.ui.detail

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.photoexam_1.R
import com.example.photoexam_1.data.model.PhotoEssay
import com.example.photoexam_1.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val detailPhoto = if(Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DETAIL_STORY, PhotoEssay::class.java)
        } else  {
            @Suppress("DEPRECATTION")
            intent.getParcelableExtra(EXTRA_DETAIL_STORY)
        }

        with(binding) {
            Glide.with(applicationContext)
                .load(detailPhoto?.storageUrl)
                .into(imageDetail)
            txtStudentName.text = detailPhoto?.studentName
            txtDescDetail.text = detailPhoto?.description
            txtAnswerKey.text = detailPhoto?.answerKey
            txtStudentAnswer.text = detailPhoto?.studentAnswer

        }

        binding.toolbarDetail.setNavigationOnClickListener { finish() }
    }

    companion object {
        const val EXTRA_DETAIL_STORY = "extra_detail_story"
    }
}